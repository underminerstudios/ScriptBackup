import sys, pprint
from pysideuic import compileUi

class convert_ui():
    '''
    nice little helper that converts .ui files to .py files in maya. local doesn't even need a version of the file
    because the inport is done after 
    '''
    def __init__(self,input_name, output_name):
        self.input_name = input_name
        self.output_name = output_name
        
    def convert(self):
        pyfile = open("%s", 'w')%(self.output_name)
        compileUi("%s", pyfile, False, 4,False)%(self.input_name)
        pyfile.close()